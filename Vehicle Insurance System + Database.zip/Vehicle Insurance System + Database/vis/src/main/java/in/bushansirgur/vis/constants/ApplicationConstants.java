package in.bushansirgur.vis.constants;

public class ApplicationConstants {
	
	public static final String MASTER_PAGE = "master";
	public static final String TITLE = "title";
	public static final String HOME = "Home";
	public static final String USER = "User";
	public static final String VEHICLE = "Vehicle";
	public static final String INSURANCE = "Insurance";
	public static final String MSG = "msg";
	public static final String SEARCH = "Search";
}
